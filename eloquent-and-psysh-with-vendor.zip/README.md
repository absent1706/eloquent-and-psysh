# PsySh + standalone Eloquent quickstart
Repo contains all the dev will need to use Eloquent and debug it with PsySh.

## Quickstart
1.
```
composer install
```

2.
Setup your DB credentials in `bin\psysh-with-eloquent.php`

3.
```
php bin\psysh-with-eloquent.php
```